import {
  iosTransitionAnimation,
  shadow
} from "./chunk-X6EMILF7.js";
import "./chunk-ZXVPTCFE.js";
import "./chunk-Y3MEIMOS.js";
import "./chunk-LQHD5MTS.js";
import "./chunk-YSZWGYJT.js";
import "./chunk-AQO6FLE6.js";
import "./chunk-B3DYXOBH.js";
export {
  iosTransitionAnimation,
  shadow
};
//# sourceMappingURL=ios.transition-BDzw0_Hm-OXC37FUM.js.map
