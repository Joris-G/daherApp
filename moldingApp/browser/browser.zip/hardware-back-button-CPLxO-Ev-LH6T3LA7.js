import {
  MENU_BACK_BUTTON_PRIORITY,
  OVERLAY_BACK_BUTTON_PRIORITY,
  blockHardwareBackButton,
  shouldUseCloseWatcher,
  startHardwareBackButton
} from "./chunk-ADHYLI4F.js";
import "./chunk-YSZWGYJT.js";
import "./chunk-AQO6FLE6.js";
import "./chunk-B3DYXOBH.js";
export {
  MENU_BACK_BUTTON_PRIORITY,
  OVERLAY_BACK_BUTTON_PRIORITY,
  blockHardwareBackButton,
  shouldUseCloseWatcher,
  startHardwareBackButton
};
//# sourceMappingURL=hardware-back-button-CPLxO-Ev-LH6T3LA7.js.map
