import {
  startFocusVisible
} from "./chunk-KQEJHESJ.js";
import "./chunk-B3DYXOBH.js";
export {
  startFocusVisible
};
//# sourceMappingURL=focus-visible-M3YWOYTS.js.map
