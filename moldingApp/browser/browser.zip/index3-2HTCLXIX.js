import {
  GESTURE_CONTROLLER,
  createGesture
} from "./chunk-MA6SXHYC.js";
import "./chunk-B3DYXOBH.js";
export {
  GESTURE_CONTROLLER,
  createGesture
};
//# sourceMappingURL=index3-2HTCLXIX.js.map
